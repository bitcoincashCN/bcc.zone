<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* topic_notify.txt */
class __TwigTemplate_583093e7b316ad575ac2e38bd19c1de0998f83d4281c9bf957bed7f24e5c13ab extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "Subject: 主题回复通知 - “";
        echo (isset($context["TOPIC_TITLE"]) ? $context["TOPIC_TITLE"] : null);
        echo "”
List-Unsubscribe: <";
        // line 2
        echo (isset($context["U_STOP_WATCHING_TOPIC"]) ? $context["U_STOP_WATCHING_TOPIC"] : null);
        echo ">

您好 ";
        // line 4
        echo (isset($context["USERNAME"]) ? $context["USERNAME"] : null);
        echo "，

您收到此通知是因为您在“";
        // line 6
        echo (isset($context["SITENAME"]) ? $context["SITENAME"] : null);
        echo "”论坛，订阅了主题, \"";
        echo (isset($context["TOPIC_TITLE"]) ? $context["TOPIC_TITLE"] : null);
        echo "\"  此主题收到一个";
        if (((isset($context["AUTHOR_NAME"]) ? $context["AUTHOR_NAME"] : null) != "")) {
            echo " 由 ";
            echo (isset($context["AUTHOR_NAME"]) ? $context["AUTHOR_NAME"] : null);
            echo " 发表的";
        }
        echo "新回复 。 您可以用下面的链接来查看回复，在您访问该主题之前不会再发送更多的通知。

如果您希望查看最新的帖子，点击下面的链接：
";
        // line 9
        echo (isset($context["U_NEWEST_POST"]) ? $context["U_NEWEST_POST"] : null);
        echo "

如果您想查看这个主题，点击下面的链接：
";
        // line 12
        echo (isset($context["U_TOPIC"]) ? $context["U_TOPIC"] : null);
        echo "

如果您想查看这个版面，点击下面的链接；
";
        // line 15
        echo (isset($context["U_FORUM"]) ? $context["U_FORUM"] : null);
        echo "

如果您不希望再订阅这个主题，您可以点击主题浏览页面中的“退订主题”链接，或者点击下面的链接:
";
        // line 18
        echo (isset($context["U_STOP_WATCHING_TOPIC"]) ? $context["U_STOP_WATCHING_TOPIC"] : null);
        echo "

";
        // line 20
        echo (isset($context["EMAIL_SIG"]) ? $context["EMAIL_SIG"] : null);
        echo "
";
    }

    public function getTemplateName()
    {
        return "topic_notify.txt";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 20,  77 => 18,  71 => 15,  65 => 12,  59 => 9,  45 => 6,  40 => 4,  35 => 2,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("", "topic_notify.txt", "");
    }
}
